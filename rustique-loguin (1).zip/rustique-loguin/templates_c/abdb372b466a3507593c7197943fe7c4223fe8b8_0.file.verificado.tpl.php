<?php
/* Smarty version 3.1.34-dev-7, created on 2020-10-11 23:22:47
  from 'C:\xampp\htdocs\tpe-web2\templates\verificado.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f8377a71019a1_13675332',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'abdb372b466a3507593c7197943fe7c4223fe8b8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tpe-web2\\templates\\verificado.tpl',
      1 => 1602451324,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f8377a71019a1_13675332 (Smarty_Internal_Template $_smarty_tpl) {
?><h1>FORROOOOOOOOOOO </h1><?php }
}
