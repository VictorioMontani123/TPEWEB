<?php

    phpinfo();


?>